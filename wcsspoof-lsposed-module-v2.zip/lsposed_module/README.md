# WCS Vendor Spoof (diagnostic, v2.0)

LSPosed/Vector module. Overrides Build.BRAND / Build.MANUFACTURER and
ro.product.*.manufacturer / *.brand to "samsung" in:

- com.samsung.wearable.watchuniteplugin
- com.samsung.android.app.watchmanager (Galaxy Wearable)
- com.samsung.android.shealthmonitor (SHM on the phone)

It also logs vendor-related SystemProperties reads with a short stack
(logcat tag `WCSSpoof`). Check real package names first:
`adb shell pm list packages | grep -iE "samsung|shealth|wearable"`

## Build

GitHub: push to the repo, run the "Build APK" workflow, download the
`wcsspoof-debug-apk` artifact (debug-signed, installable as is).

Local: JDK 17 + Gradle 8.5+ -> `gradle assembleDebug`.
