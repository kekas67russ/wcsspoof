package com.gorba.wcsspoof

import android.os.Build
import android.util.Log
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam

/**
 * v2 (diagnostic): spoofs vendor in several Samsung-related packages and logs
 * WHO reads vendor-related system properties (with a short stack trace).
 * Filter logs with: adb logcat | grep -E "WCSSpoof"
 *
 * Verify package names on the phone first:
 *   adb shell pm list packages | grep -iE "samsung|shealth|wearable"
 */
class MainHook : IXposedHookLoadPackage {

    companion object {
        private const val TAG = "WCSSpoof"
        private const val SPOOF = "samsung"

        // Add/remove after checking `pm list packages`
        private val TARGETS = setOf(
            "com.samsung.wearable.watchuniteplugin",
            "com.samsung.android.app.watchmanager",   // Galaxy Wearable
            "com.samsung.android.shealthmonitor"      // SHM on the phone
        )

        // Only these properties are overridden; the rest are just logged
        private fun shouldSpoof(key: String) =
            key.startsWith("ro.product.") &&
                (key.endsWith(".manufacturer") || key.endsWith(".brand"))

        private val INTERESTING = Regex("manufacturer|brand|model|device|knox|samsung|\\.sem|sec\\.")
        private val seen = HashSet<String>()
    }

    override fun handleLoadPackage(lpparam: LoadPackageParam) {
        if (lpparam.packageName !in TARGETS) return
        val pkg = lpparam.packageName
        log("handleLoadPackage: $pkg (process ${lpparam.processName})")

        // 1) Java-level Build fields
        for (field in listOf("BRAND", "MANUFACTURER")) {
            try {
                XposedHelpers.setStaticObjectField(Build::class.java, field, SPOOF)
                log("Build.$field -> \"$SPOOF\" in $pkg")
            } catch (t: Throwable) {
                Log.e(TAG, "Failed to set Build.$field", t)
            }
        }

        // 2) System properties read directly (bypasses Build.*)
        try {
            val cls = XposedHelpers.findClass("android.os.SystemProperties", lpparam.classLoader)
            val hook = object : XC_MethodHook() {
                override fun afterHookedMethod(param: MethodHookParam) {
                    val key = param.args.getOrNull(0) as? String ?: return
                    if (!INTERESTING.containsMatchIn(key)) return
                    val orig = param.result as? String
                    val spoof = shouldSpoof(key)
                    val caller = callerFrames()
                    val id = "$pkg|$key|${caller.firstOrNull()}"
                    if (seen.add(id)) {
                        log("SysProp read in $pkg: $key=\"$orig\"" +
                            (if (spoof) " -> \"$SPOOF\"" else "") +
                            "\n    " + caller.joinToString("\n    "))
                    }
                    if (spoof) param.result = SPOOF
                }
            }
            XposedBridge.hookAllMethods(cls, "get", hook)
            log("SystemProperties.get hooked in $pkg")
        } catch (t: Throwable) {
            Log.e(TAG, "Failed to hook SystemProperties in $pkg", t)
        }
    }

    private fun callerFrames(): List<String> =
        Throwable().stackTrace
            .filterNot {
                val c = it.className
                c.startsWith("android.os.SystemProperties") || c.startsWith("de.robv") ||
                    c.startsWith("LSPHooker") || c.startsWith("org.lsposed") ||
                    c.startsWith("com.gorba.wcsspoof") || c.startsWith("java.lang.reflect") ||
                    c.contains("Vector")
            }
            .take(6)
            .map { "${it.className}.${it.methodName}:${it.lineNumber}" }

    private fun log(msg: String) {
        Log.i(TAG, msg)
        XposedBridge.log("$TAG: $msg")
    }
}
