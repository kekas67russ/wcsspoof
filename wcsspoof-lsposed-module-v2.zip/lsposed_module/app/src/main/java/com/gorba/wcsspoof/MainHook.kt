package com.gorba.wcsspoof

import android.util.Log
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam

/**
 * v3: works ONLY inside Galaxy Wearable (com.samsung.android.app.watchmanager).
 * Build.* is NOT touched (that crashed watchuniteplugin).
 *
 * Idea: WatchDataManager.sendInitialData() decides what the phone tells the watch
 * at pairing time: isSamsungDevice() == true  -> sendPublicKey() (Samsung path)
 *                  isSamsungDevice() == false -> sendNonSamsungPopupRequest()
 * We force isSamsungDevice() = true only while sendInitialData() is running.
 *
 * Every other isSamsungDevice() call is only LOGGED (caller + original result),
 * unless FORCE_ALL = true (aggressive fallback; may cause crashes in the app).
 *
 * Logs: adb logcat | grep WCSSpoof
 */
class MainHook : IXposedHookLoadPackage {

    companion object {
        private const val TAG = "WCSSpoof"
        private const val GW = "com.samsung.android.app.watchmanager"
        private const val FORCE_ALL = false

        private val inInitial = ThreadLocal<Boolean>()
        private val seen = HashSet<String>()
    }

    override fun handleLoadPackage(lpparam: LoadPackageParam) {
        if (lpparam.packageName != GW) return
        log("handleLoadPackage: $GW (process ${lpparam.processName})")
        val cl = lpparam.classLoader

        // 1) PlatformUtils.isSamsungDevice()
        try {
            val pu = XposedHelpers.findClass(
                "com.samsung.android.app.global.utils.PlatformUtils", cl
            )
            XposedBridge.hookAllMethods(pu, "isSamsungDevice", object : XC_MethodHook() {
                override fun afterHookedMethod(param: MethodHookParam) {
                    val orig = param.result as? Boolean
                    val forced = FORCE_ALL || inInitial.get() == true
                    val caller = caller()
                    val id = "$caller|$orig|$forced"
                    if (seen.add(id)) {
                        log("isSamsungDevice() orig=$orig forced=$forced caller=$caller")
                    }
                    if (forced) param.result = true
                }
            })
            log("PlatformUtils.isSamsungDevice hooked")
        } catch (t: Throwable) {
            Log.e(TAG, "PlatformUtils hook failed (class renamed in this version?)", t)
        }

        // 2) WatchDataManager.sendInitialData(): mark the window where we force true
        try {
            val wd = XposedHelpers.findClass(
                "com.samsung.android.app.twatchmanager.connectionmanager.communication.WatchDataManager",
                cl
            )
            XposedBridge.hookAllMethods(wd, "sendInitialData", object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    inInitial.set(true)
                    log("sendInitialData() start: forcing Samsung path")
                }

                override fun afterHookedMethod(param: MethodHookParam) {
                    inInitial.set(false)
                    log("sendInitialData() end" +
                        (if (param.throwable != null) " (threw ${param.throwable})" else ""))
                }
            })
            log("WatchDataManager.sendInitialData hooked")
        } catch (t: Throwable) {
            Log.e(TAG, "WatchDataManager hook failed (class renamed in this version?)", t)
        }

        // 3) Log the other places where the manufacturer is read (no changes)
        try {
            val sc = XposedHelpers.findClass(
                "com.samsung.android.app.twatchmanager.util.StaticConstWrapper", cl
            )
            XposedBridge.hookAllMethods(sc, "getManufacturer", object : XC_MethodHook() {
                override fun afterHookedMethod(param: MethodHookParam) {
                    val caller = caller()
                    if (seen.add("mf|$caller")) {
                        log("getManufacturer()=\"${param.result}\" caller=$caller")
                    }
                }
            })
            log("StaticConstWrapper.getManufacturer hooked (log only)")
        } catch (t: Throwable) {
            Log.e(TAG, "StaticConstWrapper hook failed", t)
        }
    }

    private fun caller(): String =
        Throwable().stackTrace
            .filterNot {
                val c = it.className
                c.startsWith("de.robv") || c.startsWith("LSPHooker") ||
                    c.startsWith("org.lsposed") || c.startsWith("com.gorba.wcsspoof") ||
                    c.startsWith("java.lang.reflect") || c.contains("Vector") ||
                    c.endsWith("PlatformUtils") || c.endsWith("StaticConstWrapper")
            }
            .take(2)
            .joinToString(" <- ") { "${it.className.substringAfterLast('.')}.${it.methodName}" }

    private fun log(msg: String) {
        Log.i(TAG, msg)
        XposedBridge.log("$TAG: $msg")
    }
}
